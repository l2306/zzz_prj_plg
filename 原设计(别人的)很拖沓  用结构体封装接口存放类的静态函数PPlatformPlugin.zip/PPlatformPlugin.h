#ifndef _H_H_PPLATFORM_PLUGIN
#define _H_H_PPLATFORM_PLUGIN
#include <string>
#include <cstring>
#include <vector>


#include "PPlatform.h"

using namespace std;

class CPPlatformPluginUnit
{
public:
	CPPlatformPluginUnit() : m_pSendMFunc(NULL),
		m_pSendTrayFunc(NULL), m_pSendFileFunc(NULL), m_pSendDB2Func(NULL),
        m_iProductID(0), m_iBussinessID(0), m_strName("")
	  {
	  }

	virtual ~CPPlatformPluginUnit() {}
	virtual int Init(int CorS) = 0;
	virtual int UnInit() = 0;
	virtual int DoOnce() = 0;
	virtual int SetMessage(struct struI_CommonMSG * p) = 0;
	int GetProductID() const                    { return m_iProductID; }
	int GetBussinessID() const                  { return m_iBussinessID; }
	int GetStatus(struct Status * p) const      { return 0; }
	string GetName() const                      { return m_strName; }
	pFuncSendMessage GetSendMessageCB() const   { return m_pSendMFunc; }
	pFuncSendMessage2Tray GetSendMessage2TrayCB() const { return m_pSendTrayFunc; }
	pFuncSendFile GetSendFile2CB() const        { return m_pSendFileFunc; }
	pFuncSendMessage2DB2 GetSendMessage2DB2() const { return m_pSendDB2Func; }
	int SetProductID(int id) { m_iProductID = id; }

	int SetBussinessID(int id){m_iBussinessID = id; }

	int SetName(const string& name)
	{ m_strName = name; }

	int SetSendMessageCB(pFuncSendMessage Func)
	{
		m_pSendMFunc = Func;
		return 0;
	}

	int SetSendMessage2TrayCB(pFuncSendMessage2Tray Func)
	{
		m_pSendTrayFunc = Func;
		return 0;
	}

	int SetSendFile2CB(pFuncSendFile Func)
	{
		m_pSendFileFunc = Func;
		return 0;
	}

	int SetSendMessage2DBCB2(pFuncSendMessage2DB2 Func)
	{
		m_pSendDB2Func = Func;
	}

protected:

	pFuncSendMessage      m_pSendMFunc;
	pFuncSendMessage2Tray m_pSendTrayFunc;
	pFuncSendFile         m_pSendFileFunc;
	pFuncSendMessage2DB2  m_pSendDB2Func;
private:
	int         m_iProductID;
	int         m_iBussinessID;
	string      m_strName;
};

#define ForEach(func) for(int i = 0; i < m_vecUnit.size(); ++i)m_vecUnit[i]->func() 

#define ForEach1(func, arg) for(int i = 0; i < m_vecUnit.size(); ++i)m_vecUnit[i]->func(arg)

#define DEFCLASS(CPPlatformPlugin) class CPPlatformPlugin\
{\
public:\
	CPPlatformPlugin(const string& Name, int ProductID, int BussinessID)\
	{\
		SetPluginInfo(Name, ProductID, BussinessID);\
	}\
	CPPlatformPlugin(CPPlatformPluginUnit* pPluginUnit)\
	{\
		AddPluginUnit(pPluginUnit);\
	}\
	static int Init(int CorS);\
	static int UnInit();\
	static int DoOnce();\
	static int SetMessage(struct struI_CommonMSG * p);\
	static int GetProductID();\
	static int GetBussinessID();\
	static int GetStatus(struct Status * p);\
	static int GetInformation(struct ModuleInformation* p);\
	static int SetSendMessageCB(pFuncSendMessage Func);\
private:\
	static int SetProductID(int id);\
	static int SetBussinessID(int id);\
	static int SetName(const string& name);\
	static void SetPluginInfo(const string& Name, int ProductID, int BussinessID);\
	static void AddPluginUnit(CPPlatformPluginUnit* pPluginUnit);\
	static void Clear();\
private:\
	static int  m_iProductID;\
	static int  m_iBussinessID;\
	static string m_strName;\
	static vector<CPPlatformPluginUnit*> m_vecUnit;\
};\
int  CPPlatformPlugin::m_iProductID(0);\
int  CPPlatformPlugin::m_iBussinessID(0);\
string CPPlatformPlugin::m_strName("");\
vector<CPPlatformPluginUnit*> CPPlatformPlugin::m_vecUnit;\
int CPPlatformPlugin::Init(int CorS)\
{\
	ForEach1(Init, CorS);\
	return 0;\
}\
int CPPlatformPlugin::UnInit()\
{\
	ForEach(UnInit);\
	Clear();\
	return 0;\
}\
int CPPlatformPlugin::DoOnce()\
{\
	ForEach(DoOnce);\
	return 0;\
}\
int CPPlatformPlugin::SetMessage(struct struI_CommonMSG * p)\
{\
	ForEach1(SetMessage, p);\
	return 0;\
}\
int CPPlatformPlugin::SetProductID(int id)\
{\
	m_iProductID = id;\
	ForEach1(SetProductID, id);\
	return 0;\
}\
int CPPlatformPlugin::SetBussinessID(int id)\
{\
	m_iBussinessID = id;\
	ForEach1(SetBussinessID, id);\
	return 0;\
}\
int CPPlatformPlugin::SetName(const string& name)\
{\
	m_strName = name;\
	ForEach1(SetName, name);\
	return 0;\
}\
int CPPlatformPlugin::SetSendMessageCB(pFuncSendMessage Func)\
{\
	ForEach1(SetSendMessageCB, Func);\
	return 0;\
}\
int CPPlatformPlugin::SetSendMessage2TrayCB(pFuncSendMessage2Tray Func)\
{\
	ForEach1(SetSendMessage2TrayCB, Func);\
	return 0;\
}\
int CPPlatformPlugin::SetSendFile2CB(pFuncSendFile Func)\
{\
	ForEach1(SetSendFile2CB, Func);\
	return 0;\
}\
int CPPlatformPlugin::SetSendMessage2DBCB2(pFuncSendMessage2DB2 Func)\
{\
	ForEach1(SetSendMessage2DBCB2, Func);\
	return 0;\
}\
int CPPlatformPlugin::GetProductID ()\
{\
	return m_iProductID;\
}\
int CPPlatformPlugin::GetBussinessID()\
{\
	return m_iBussinessID;\
}\
int CPPlatformPlugin::GetStatus(struct Status * p)\
{\
	return 0;\
}\
int CPPlatformPlugin::GetInformation(struct ModuleInformation* p)\
{\
	if (p == NULL)\
	{\
		return -1;\
	}\
	p->productID = GetProductID();\
	p->bussinessID = GetBussinessID();\
	strncpy(p->name, m_strName.c_str(), sizeof(p->name));\
	p->versionNum = 1;\
	p->other[0] = 0;\
	return 0;\
}\
void CPPlatformPlugin::SetPluginInfo(const string& Name, int ProductID, int BussinessID)\
{\
	SetName(Name);\
	SetProductID(ProductID);\
	SetBussinessID(BussinessID);\
}\
void CPPlatformPlugin::AddPluginUnit(CPPlatformPluginUnit* pPluginUnit)\
{\
	pPluginUnit->SetName(m_strName);\
	pPluginUnit->SetProductID(m_iProductID);\
	pPluginUnit->SetBussinessID(m_iBussinessID);\
	m_vecUnit.push_back(pPluginUnit);\
}\
void CPPlatformPlugin::Clear()\
{\
	for(int i = 0; i < m_vecUnit.size(); ++i) if (m_vecUnit[i]) delete m_vecUnit[i];\
	m_vecUnit.clear();\
}\
extern "C" DLL_PUBLIC int GetVersion_Int() { return 1; }\
extern "C" DLL_PUBLIC IInterface * MakeIInterface()\
{\
	struct IInterface * p =  new IInterface;\
	p->Init = CPPlatformPlugin::Init;\
	p->GetProductID = CPPlatformPlugin::GetProductID;\
	p->GetBussinessID = CPPlatformPlugin::GetBussinessID;\
	p->DoOnce = CPPlatformPlugin::DoOnce;\
	p->SetMessage = CPPlatformPlugin::SetMessage;\
	p->GetStatus = CPPlatformPlugin::GetStatus;\
	p->GetInformation = CPPlatformPlugin::GetInformation;\
	p->SetSendMessageCB = CPPlatformPlugin::SetSendMessageCB;\
	p->SetSendMessage2TrayCB = CPPlatformPlugin::SetSendMessage2TrayCB;\
	p->SetSendFile2CB = CPPlatformPlugin::SetSendFile2CB;\
	p->SetSendMessage2DBCB2 = CPPlatformPlugin::SetSendMessage2DBCB2;\
	p->UnInit = CPPlatformPlugin::UnInit;\
	return p;\
}

struct struI_CommonMSG* CreateCommonMSG(BYTE* data, int len, 
        int iDesType, int iDesProductID, int iDesBussinessID,
		int iSrcType, int iSrcProductID, int iSrcBusinessID,
		int iSocketID = 0);

struct struI_CommonMSG* CopyCommonMSGEx(struI_CommonMSG* pMSG);

#define RegPlugin(Name, ProductID, BussinessID)   DEFCLASS(Name); Name NameObject(#Name, ProductID, BussinessID);
#define AddPluginUnitClass(Name, ClassName, Index) Name NameObjectIndex(new ClassName);

#endif 