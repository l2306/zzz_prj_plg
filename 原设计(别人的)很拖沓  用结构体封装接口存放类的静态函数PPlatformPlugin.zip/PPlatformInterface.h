#ifndef H_modname_H
#define H_modname_H


#include <queue>
#include <string.h>

#include "PPlatform.h"

using namespace std;

#define PRegModName(modname) class modname\
{\
public:\
	static int Init(int CorS);\
	static int UnInit();\
	static int DoOnce();\
	static int GetProductID();\
	static int GetBussinessID();\
	static int GetStatus(struct Status * p);\
	static int GetInformation(struct ModuleInformation* p);\
	static int SetMessage(struct struI_CommonMSG* p);\
	static int SetSendMessageCB(pFuncSendMessage Func);\
	static int SetSendMessage2TrayCB(pFuncSendMessage2Tray Func);\
	static int SetSendFile2CB(pFuncSendFile Func);\
	static int SetSendMessage2DBCB2(pFuncSendMessage2DB2 Func);\
	static int SetSendMessage2DBCB3(pFuncSendMessage2DB3 Func);\
	static int SetSendMessage2DBCB4(pFuncSendMessage2DB4 Func);\
	static struI_CommonMSG* CreateMSG(const BYTE* pData, const int len);\
	static void ReleaseMSG(struI_CommonMSG*& pMSG);\
	static void Release();\
public:\
	static pFuncSendMessage			pSendM;\
	static pFuncSendFile			pSendF;\
	static pFuncSendMessage2Tray	pSendTray;\
	static pFuncSendMessage2DB2		pSendDB2;\
	static pFuncSendMessage2DB3		pSendDB3;\
	static pFuncSendMessage2DB4		pSendDB4;\
	static queue<struI_CommonMSG*>  queueMSG;\
private:\
	static int productID;\
	static int bussineID;\
	static char* strName;\
};\
pFuncSendMessage			modname::pSendM(NULL);\
pFuncSendFile			    modname::pSendF(NULL);\
pFuncSendMessage2Tray	    modname::pSendTray(NULL);\
pFuncSendMessage2DB2		modname::pSendDB2(NULL);\
pFuncSendMessage2DB3		modname::pSendDB3(NULL);\
pFuncSendMessage2DB4		modname::pSendDB4(NULL);\
queue<struI_CommonMSG*>     modname::queueMSG;\
int modname::GetProductID()\
{\
	return productID;\
}\
int modname::GetBussinessID()\
{\
	return bussineID;\
}\
int modname::GetStatus(struct Status * p)\
{\
	return 0;\
}\
int modname::GetInformation(struct ModuleInformation* p)\
{\
	if (p == NULL)\
	{\
		return -1;\
	}\
	p->productID = GetProductID();\
	p->bussinessID = GetBussinessID();\
	strncpy(p->name, strName, sizeof(p->name));\
	p->versionNum = 1;\
	p->other[0] = 0;\
	return 0;\
}\
int modname::SetMessage(struct struI_CommonMSG* p)\
{\
	if((p->iDesProductID == GetProductID() &&\
		p->iDesBussinessID == GetBussinessID()))\
	{\
		struI_CommonMSG* pMSG = new struI_CommonMSG;\
		if(pMSG == NULL)\
		{\
			return -1;\
		}\
		memset((void *)pMSG, 0, sizeof(struI_CommonMSG));\
		memcpy((void *)pMSG, p, sizeof(struI_CommonMSG));\
		pMSG->data = new BYTE[p->iLength];\
		memcpy(pMSG->data, p->data, p->iLength);\
		queueMSG.push(pMSG);\
	}\
	return 0;\
}\
int modname::SetSendMessageCB(pFuncSendMessage Func)\
{\
	pSendM = Func;\
	return 0;\
}\
int modname::SetSendMessage2TrayCB(pFuncSendMessage2Tray Func)\
{\
	pSendTray = Func;\
	return 0;\
}\
int modname::SetSendFile2CB(pFuncSendFile Func)\
{\
	pSendF = Func;\
	return 0;\
}\
int modname::SetSendMessage2DBCB2(pFuncSendMessage2DB2 Func)\
{\
	pSendDB2 = Func;\
	return 0;\
}\
int modname::SetSendMessage2DBCB3(pFuncSendMessage2DB3 Func)\
{\
	pSendDB3 = Func;\
	return 0;\
}\
int modname::SetSendMessage2DBCB4(pFuncSendMessage2DB4 Func)\
{\
	pSendDB4 = Func;\
	return 0;\
}\
struI_CommonMSG* modname::CreateMSG(const BYTE* pData, const int len)\
{\
	struI_CommonMSG* pMSG = new struI_CommonMSG;\
	if(pMSG == NULL)\
	{\
		return NULL;\
	}\
	memset(pMSG, 0,  sizeof(struI_CommonMSG));\
	pMSG->iSrcType         =  CS_CLIENT;\
	pMSG->iSrcProductID    =  GetProductID();\
	pMSG->iSrcBusinessID   =  GetBussinessID();\
	pMSG->iDesType         =  CS_SERVER;\
	pMSG->iDesProductID    =  GetProductID();\
	pMSG->iDesBussinessID  =  GetBussinessID();\
	pMSG->iLength          =  len + 1;\
	pMSG->data             =  new BYTE[pMSG->iLength];\
	if(pMSG->data == NULL)\
	{\
		delete pMSG;\
		return NULL;\
	}\
	memset(pMSG->data, 0, pMSG->iLength);\
	memcpy(pMSG->data, pData, len);\
	return pMSG;\
}\
void modname::ReleaseMSG(struI_CommonMSG*& pMSG)\
{\
	if(pMSG)\
	{\
		if(pMSG->data)\
		{\
			delete[] pMSG->data;\
			pMSG->data = NULL;\
		}\
		delete pMSG;\
		pMSG = NULL;\
	}\
}\
void modname::Release()\
{\
	while(!queueMSG.empty())\
	{\
		ReleaseMSG(queueMSG.front());\
		queueMSG.pop();\
	}\
}\
extern "C" DLL_PUBLIC int GetVersion_Int()\
{\
	return 1;\
}\
extern "C" DLL_PUBLIC IInterface * MakeIInterface()\
{\
	struct IInterface * p =  new IInterface;\
	p->Init = modname::Init;\
	p->GetProductID = modname::GetProductID;\
	p->GetBussinessID = modname::GetBussinessID;\
	p->DoOnce = modname::DoOnce;\
	p->SetMessage = modname::SetMessage;\
	p->GetStatus = modname::GetStatus;\
	p->GetInformation = modname::GetInformation;\
	p->SetSendMessageCB = modname::SetSendMessageCB;\
	p->SetSendMessage2TrayCB = modname::SetSendMessage2TrayCB;\
	p->SetSendFile2CB = modname::SetSendFile2CB;\
	p->SetSendMessage2DBCB2 = modname::SetSendMessage2DBCB2;\
	p->SetSendMessage2DBCB3 = modname::SetSendMessage2DBCB3;\
	p->SetSendMessage2DBCB4 = modname::SetSendMessage2DBCB4;\
	p->UnInit = modname::UnInit;\
	return p;\
}

#endif
