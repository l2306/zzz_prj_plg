#include "PPlatformPlugin.h"

struct struI_CommonMSG* CreateCommonMSG(BYTE* data, int len, 
        int iDesType, int iDesProductID, int iDesBussinessID,
		int iSrcType, int iSrcProductID, int iSrcBusinessID,
		int iSocketID = 0)
{
	struI_CommonMSG* pMSG = new struI_CommonMSG;
	if(pMSG == NULL)
	{
		return NULL;
	}
	memset(pMSG, 0,  sizeof(struI_CommonMSG));
	pMSG->iDesType         =  iDesType;
	pMSG->iDesProductID    =  iDesProductID;
	pMSG->iDesBussinessID  =  iDesBussinessID;
	pMSG->iSrcType         =  iSrcType;
	pMSG->iSrcProductID    =  iSrcProductID;
	pMSG->iSrcBusinessID   =  iSrcBusinessID;
	pMSG->iLength          =  len + 1;
	pMSG->data             =  new BYTE[pMSG->iLength];
	if(pMSG->data == NULL)
	{
		delete pMSG;
		return NULL;
	}
	memset(pMSG->data, 0, pMSG->iLength);
	memcpy(pMSG->data, data, len);
	return pMSG;
}

struct struI_CommonMSG* CopyCommonMSGEx(struI_CommonMSG* pMsg)
{
	if(!pMsg)
	{
		return NULL;
	}

	struI_CommonMSG* pMsg1 =  new struI_CommonMSG;
	if(!pMsg1)
	{
		return NULL;
	}

	memcpy(pMsg1, pMsg, sizeof(struI_CommonMSG));
	pMsg1->data = new BYTE[pMsg->iLength];
	if(!pMsg1->data)
	{
		delete pMsg1;
		return NULL;
	}
	memcpy(pMsg1->data, pMsg->data, pMsg->iLength);
	return pMsg1;
}