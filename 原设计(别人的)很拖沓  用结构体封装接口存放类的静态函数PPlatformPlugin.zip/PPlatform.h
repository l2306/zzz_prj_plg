#ifndef H_PPLATFORM_H
#define H_PPLATFORM_H


#define		CS_CLIENT	1
#define		CS_SERVER	2
#define		BS_SERVER	3
#define		UP_SERVER	4
#define		DOWN_SERVER	5

#define		P_Platform	1

#define		B_Register	1
#define		B_Login		2
#define		B_Logout	3
#define		B_Heartbeat	4
#define		B_Db		5
#define		B_Tray		6
#define		B_Host		7
#define		B_State		8
#define		B_IM		9
#define		B_Web		10
#define		B_TransFile 11
#define     B_HostInfo  12
#define		B_HostRes   13
#define     B_TimeSync  14
#define		B_LogM      15
#define		B_Cascade	16
#define		B_CARegC	17
#define		B_CARegS	18
#define		B_CALoginC	19
#define		B_CALoginS	20


typedef unsigned char BYTE;

#pragma pack(push, 1)

struct struI_CommonMSG
{
	int 			iSrcType;
	int 			iSrcProductID;
	int 			iSrcBusinessID;
	int 			iDesType;
	int 			iDesProductID;
	int 			iDesBussinessID;
	unsigned int	iSocketID;
	int 			iMessageID;
	int 			iSerialNO;
	int 			iLength;
	BYTE*			data;
};

struct Status
{
	char data[512];
};

struct ModuleInformation
{
	int		productID;
	int		bussinessID;
	char	name[64];
	int		versionNum;
	BYTE	other[512];	
};

#pragma pack(pop)

typedef int (*pFuncSendMessage)(struct struI_CommonMSG* p);
typedef int (*pFuncSendMessage2Tray)(char* Message,unsigned char ucVoice , unsigned char ucType);
typedef int (*pFuncSendFile)(int iSocket, int iProductID, int iBussnessID, char* szFileName);
typedef int (*pFuncSendMessage2DB2)(char* sql, int imysql);
typedef int (*pFuncSendMessage2DB3)(int imysql, int iProductID, int iBussinessID);
typedef int (*pFuncSendMessage2DB4)(char* sql, int imysql, int iProductID, int iBussinessID);

struct IInterface
{
	int (*Init)(int CorS);
	int (*UnInit)();
	int (*DoOnce)();
	int (*GetProductID)();
	int (*GetBussinessID)();
	int (*GetStatus)(struct Status* p);
	int (*GetInformation)(struct ModuleInformation* p);
	int (*SetMessage)(struct struI_CommonMSG* p);
	int (*SetSendMessageCB)(pFuncSendMessage Func);
	int (*SetSendMessage2TrayCB)(pFuncSendMessage2Tray Func);
	int (*SetSendFile2CB)(pFuncSendFile Func);
	int (*SetSendMessage2DBCB2)(pFuncSendMessage2DB2 Func);
	int (*SetSendMessage2DBCB3)(pFuncSendMessage2DB3 Func);
	int (*SetSendMessage2DBCB4)(pFuncSendMessage2DB4 Func);	
};

#ifndef WIN32
#define DLL_PUBLIC __attribute__((visibility("default")))
#else
 #ifndef DLL_PUBLIC
 #define DLL_PUBLIC __declspec(dllexport )
 #endif
#endif

extern "C" DLL_PUBLIC int GetVersion_Int();

extern "C" DLL_PUBLIC IInterface* MakeIInterface();

#endif
